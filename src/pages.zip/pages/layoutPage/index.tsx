import { Outlet, Link, useLocation, useNavigate } from "react-router-dom";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faHome } from "@fortawesome/free-solid-svg-icons";

const Layout = () => {
  const { state } = useLocation();
  const navigate = useNavigate()

  console.log(state);
  const onLogout=()=>{
    navigate('/login',{
      replace:true
    })
  }

  return (
    <>
      <nav className="navbar">
        {state?.logged ? (
          <div className="user">
            <span className="username">{state?.name}</span>
            <button className="btn-logout" onClick={onLogout}>Cerrar Sesión</button>
          </div>
        ) : (
          <ul className="nav-links">
            <li>
              <Link to="/login">Login</Link>
            </li>
            <li>
              <Link to="/registro">Registrarse</Link>
            </li>
            <li>
              <Link to="/home">
                <FontAwesomeIcon icon={faHome} />
              </Link>
            </li>
          </ul>
        )}
      </nav>
      <Outlet />
    </>
  );
};

export default Layout;
