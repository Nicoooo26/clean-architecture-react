import { Link } from "react-router-dom";
import { useNavigate } from "react-router-dom";
import React,{ useState } from "react";

const Login = () => {

  const navigate = useNavigate()
  const [username, setUsername] = useState<string>("");

  const logear = (e:React.FormEvent) => {
    e.preventDefault()

    navigate('/home',{
      replace:true,
      state:{
        logged:true,
        name:username
      }
    })
  }
  return (
    <div className="modal">
      <div className="modal-content">
        <form onSubmit={logear}>
        <h2>Login</h2>
        <input type="text" placeholder="Username" value={username}
            onChange={(e) => setUsername(e.target.value)} />
        <input type="password" placeholder="Password"/>
        <button type="submit">Login</button>
        </form>
        <Link to="/registro">
          <button>Close</button>
        </Link>
      </div>
    </div>
  );
};

export default Login;
