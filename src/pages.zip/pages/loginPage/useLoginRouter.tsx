import { Route } from "react-router-dom";
import Login from ".";
import Layout from "../layoutPage";
import Registro from "../registroPage";

const logeado = false;

export const useCustomRouter = () => {
  const renderComponent = () => {
    if (logeado) {
      return <Registro />;
    } else {
      return <Login />;
    }
  };

  return (
    <>
    <Route path="/" element={Layout()}>
      <Route path="/login" element={renderComponent()} />
      <Route path="/registro" element={Registro()} />

      </Route>
    </>
  );
};

