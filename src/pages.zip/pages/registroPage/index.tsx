import { Link } from "react-router-dom";

const Registro = () => {
  return (
    <div className="modal">
      <div className="modal-content">
        <h2>Registro</h2>
        <input type="text" placeholder="Username" />
        <button>Registro</button>
        <Link to="/home">
          <button>Close</button>
        </Link>
      </div>
    </div>
  );
};

export default Registro;
