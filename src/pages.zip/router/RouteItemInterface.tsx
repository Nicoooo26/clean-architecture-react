import { ReactNode } from 'react';

export default interface RouteItem {
    path: string;
    builder:() => ReactNode;
}
